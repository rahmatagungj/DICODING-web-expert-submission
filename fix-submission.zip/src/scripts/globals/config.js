const CONFIG = {
  DATABASE_NAME: 'restaurant-database',
  DATABASE_VERSION: 1,
  OBJECT_STORE_NAME: 'restaurant',
  SERVER_IMAGE_URL: 'https://dicoding-restaurant-api.el.r.appspot.com/images/medium/',
  SERVER_API_URL: 'https://restaurant-api.dicoding.dev'
}

export default CONFIG
